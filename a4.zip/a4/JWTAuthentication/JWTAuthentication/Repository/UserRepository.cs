﻿using JWTAuthentication.Repository.IRepository;

namespace JWTAuthentication.Repository
{
    public class UserRepository : IUserRepository
    {
        public UserRepository()
        {

        }
    }
}
