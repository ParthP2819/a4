﻿namespace JWTAuthentication.Repository.IRepository
{
    public interface IUserRepository
    {
    }
}
