﻿namespace IdentityApi.Repository.IRepository
{
    public interface IUser
    {
    }
}
