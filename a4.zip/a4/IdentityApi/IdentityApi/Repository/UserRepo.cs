﻿namespace IdentityApi.Repository
{
    public class UserRepo
    {
    }
}
