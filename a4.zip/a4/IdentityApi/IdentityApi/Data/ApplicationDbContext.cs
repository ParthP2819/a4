﻿using IdentityApi.Entities;
using IdentityApi.Model;
using Microsoft.EntityFrameworkCore;

namespace IdentityApi.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<User> user { get; set; }
        public DbSet<UserRequest> userRequests { get; set; }      
        public DbSet<UserResponse> userResponse { get; set; }

    }
}
