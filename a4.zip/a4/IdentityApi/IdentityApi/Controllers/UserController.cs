﻿using IdentityApi.Data;
using IdentityApi.Entities;
using IdentityApi.Model;
using IdentityApi.Repository;
using IdentityApi.Repository.IRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace IdentityApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        public UserController(ApplicationDbContext db)
        {
            _db= db;
        }
        [AllowAnonymous]
        [HttpPost]
        [Route("Rigistrtion/")]
        public IActionResult UserRegistration(User user)
        {

            _db.user.Add(user);
            _db.SaveChanges();


            return Ok(user);
        }



        [AllowAnonymous]
        [HttpPost]
        [Route("Login/")]
        public IActionResult UserLogin(UserRequest user)
        {

            var data = _db.user.Where(x => x.UserName == user.UserName && x.Password == user.Password).FirstOrDefault();

            if (data == null)
            {
                return BadRequest("Invalid UserName And Password");

            }

            else
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes("Create JWt token identifier");
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new[] { new Claim("id", user.UserName) }),
                    Expires = DateTime.UtcNow.AddDays(1),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha512Signature)
                };
                var token = tokenHandler.CreateToken(tokenDescriptor);
                var encrypterToken = tokenHandler.WriteToken(token);

                return Ok(new { token = encrypterToken, Username = user.UserName });
            }


        }



 

    }
}
