﻿using IdentityApi.Entities;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace IdentityApi.Model
{
    public class UserRequest
    {
        public int id { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required] 
        public string Password { get; set; }
    }
}
