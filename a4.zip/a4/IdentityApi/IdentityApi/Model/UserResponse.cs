﻿using IdentityApi.Entities;
using System.Data;

namespace IdentityApi.Model
{
    public class UserResponse
    {
        public int Id { get; set; }
     
        public string Username { get; set; }
      
        public string Token { get; set; }
    }
}
