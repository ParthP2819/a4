﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> myNo = new List<int>();
            myNo.Add(12);
            myNo.Add(23);
            Console.WriteLine(myNo.Capacity);
        }
    }
}
