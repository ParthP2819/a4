﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Exam_dotnet.Data;
using Exam_dotnet.Models;
using Microsoft.CodeAnalysis.Scripting;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace Exam_dotnet.Controllers
{
    public class SubCategoriesScapController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SubCategoriesScapController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: SubCategoriesScap
        //public IActionResult Index()
        //{
        //    return View();
        //}
        public async Task<IActionResult> Index()
        {
            return View(await _context.SCategory.ToListAsync());
        }

        // GET: SubCategoriesScap/AddChild/5
        public async Task<IActionResult> AddChild(int? id)
        {

            if (id == null || _context.SCategory == null)
            {
                return NotFound();
            }

            var subCategory = await _context.SCategory
                .FirstOrDefaultAsync(m => m.SubCategoryId == id);
            if (subCategory == null)
            {
                return NotFound();
            }

            return View(subCategory);
        }

        // GET: SubCategoriesScap/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: SubCategoriesScap/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("SubCategoryId,Name,Description,IsActive,CreatedOn,ModifiedOn,ParentCategoryId")] SubCategory subCategory)
        {
            if (ModelState.IsValid)
            {
                _context.Add(subCategory);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(subCategory);
        }

        // GET: SubCategoriesScap/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.SCategory == null)
            {
                return NotFound();
            }

            var subCategory = await _context.SCategory.FindAsync(id);
            if (subCategory == null)
            {
                return NotFound();
            }
            return View(subCategory);
        }

        // POST: SubCategoriesScap/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("SubCategoryId,Name,Description,IsActive,CreatedOn,ModifiedOn,ParentCategoryId")] SubCategory subCategory)
        {
            if (id != subCategory.SubCategoryId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(subCategory);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SubCategoryExists(subCategory.SubCategoryId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(subCategory);
        }

        // GET: SubCategoriesScap/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.SCategory == null)
            {
                return NotFound();
            }

            var subCategory = await _context.SCategory
                .FirstOrDefaultAsync(m => m.SubCategoryId == id);
            if (subCategory == null)
            {
                return NotFound();
            }

            return View(subCategory);
        }

        // POST: SubCategoriesScap/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.SCategory == null)
            {
                return Problem("Entity set 'ApplicationDbContext.SCategory'  is null.");
            }
            var subCategory = await _context.SCategory.FindAsync(id);
            if (subCategory != null)
            {
                _context.SCategory.Remove(subCategory);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SubCategoryExists(int id)
        {
            return _context.SCategory.Any(e => e.SubCategoryId == id);
        }

        #region APICALLS

        [HttpGet]
        public IActionResult GetAll()
        {
            var CategoryList = _context.SCategory.ToList();
            return Json(new { Data = CategoryList });
        }
        #endregion
    }
}