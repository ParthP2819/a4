﻿using Exam_dotnet.Models;
using Microsoft.EntityFrameworkCore;

namespace Exam_dotnet.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        //public DbSet<ParentCategory> PCategory { get; set; }
        public DbSet<SubCategory> SCategory { get; set; }   
    }
}
