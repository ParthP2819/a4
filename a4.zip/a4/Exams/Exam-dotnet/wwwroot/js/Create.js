﻿var DataTable;

$(document).ready(function () {
    loadDataTable();
})

function loadDataTable() {
    DataTable = $('#tblData').DataTable({
    "ajax": {
        "url": "/SubCategoriesScap/GetAll"
    },
    "columns": [
        { "data": "name", "width": "15%" },
        { "data": "description", "width": "15%" },
        { "data": "isActive", "width": "15%" },
        {
            "data": "subCategoryId",
            "render": function (data) {
                return `
                    <div class="w-75 btn-group" role="group">

                        ////<a class="btn btn-primary mx-2" onclick="outputEdit('SubCategoriesScap/Edit/?id=${data}','Edit Category')">Edit</a>
                        ////<a class="btn btn-primary mx-2" onclick="outputDelete('SubCategoriesScap/Delete/?id=${data}','Delete Category')">Delete</a>
                        ////<a class="btn btn-secondary" onclick="outputChild('SubCategoriesScap/Index/?id=${data}','Add a new child')>Add Child</a>
 
                       
                        <a class="btn btn-primary mx-2" onclick="outputEdit('SubCategoriesScap/Edit/?id=${data}','Edit Category')">Edit</a>
                        <a class="btn btn-primary mx-2" onclick="outputDelete('SubCategoriesScap/Delete/?id=${data}','Delete Category')">Delete</a>
                        <a class="btn btn-secondary" onclick="outputChild('SubCategoriesScap/Index/?id=${data}','Add a new child')>Add Child</a>
                    </div>
                        `
            },
            "width": "15%"
        }
        ],
    });
}

function outputEdit(url, title) { 
    $.ajax({
        type: "GET",
        url: url,
        success: function (data) {
            $('#popOutput .modal-body').html(data);
            $('#popOutput .modal-title').html(title);
            $('#popOutput').modal('show');
        }
    })
}

function outputDelete(url, title) {
    $.ajax({
        type: "GET",
        url: url,
        success: function (data) {
            $('#popOutput .modal-body').html(data);
            $('#popOutput .modal-title').html(title);
            $('#popOutput').modal('show');
        }
    })
}

function DeleteCall(id) {
    $('#btnDelete').click(function (e) {
        $.ajax({
            type: "POST",
            url: '@Url.Action("Delete","Category")',
            success: function () {
                location.reload();
            }
            })
    })
}