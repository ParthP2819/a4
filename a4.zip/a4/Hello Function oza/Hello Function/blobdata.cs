using System;
using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.Cosmos.Table;

namespace Hello_Function
{
    public class blobdata
    {
        [FunctionName("blobdata")]
        public void Run([BlobTrigger("blob-data/{name}", Connection = "ConnectionStr")] Stream myBlob, string name, ILogger log)
        {
            StreamReader streamReader = new StreamReader(myBlob);
            log.LogInformation($"C# Blob trigger function Processed blob\n Name:{name} \n Size: {myBlob.Length} Bytes\n content:{streamReader.ReadToEnd()}");
        }

        [FunctionName("create")]
        public static async Task<IActionResult> abc(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            // Get Storage Information
            var accountName = "3GVQtyD1UaOA2Kjz6XuEw0yu/ku93bJ8tj5aFfJoKV1zfbv9Fl7zzzhvG88sk/xbSSVyZmWL41gT+ASt4W8XRA==";
            var accountKey = "parthstorageaccounts";

            // Set Auth
            var creds = new StorageCredentials(accountName, accountKey);
            var account = new CloudStorageAccount(creds, useHttps: true);

            // Connect to Storage
            var client = account.CreateCloudTableClient();
            var table = client.GetTableReference("YourAzureTableName");

            string responseMessage = "created success";
            return new OkObjectResult(responseMessage);
        }
    }
}
